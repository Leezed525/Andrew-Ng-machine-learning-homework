# Andrew-NG-Meachine-Learning
coursera中Andrew Ng的meachine learning的所有编程测验的原文件
看到网上的下载都是要cf币，倍感心痛，特下载之服务于广大网友(￣▽￣)"
